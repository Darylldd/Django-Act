from django.shortcuts import render

def index(request):
    return render(request, 'app2/index.html')

def gallery(request):
    return render(request, 'app2/gallery.html')

def feedback(request):
    return render(request, 'app2/feedback.html')
